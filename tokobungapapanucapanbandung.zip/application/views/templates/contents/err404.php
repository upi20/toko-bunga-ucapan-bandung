    <!-- Main content -->
    <section class="content">
    	<div class="align-middle">
    		<div class="error-content pt-4">
    			<h3>
    				<i class="text-warning">Error</i><i class="fas fa-exclamation-triangle text-warning"></i> Anda tidak memiliki hak akses terhadap fitur ini. <a href="<?= base_url() ?>">kembali ke dashboard</a>
    			</h3>
    		</div>
    		<!-- /.error-content -->
    	</div>
    	<!-- /.error-page -->
    </section>
    <!-- /.content -->